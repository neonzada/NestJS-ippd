import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { Modulo1Module } from './modulo1/modulo1.module';
import { TasksModule } from './tasks/tasks.module';

@Module({
  imports: [Modulo1Module, TasksModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
